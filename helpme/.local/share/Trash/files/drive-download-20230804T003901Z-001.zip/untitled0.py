# -*- coding: utf-8 -*-
"""
Created on Wed Jul 26 09:00:00 2023

@author: mfogel
"""

#import serial.tools.list_ports as port_list

import serial
import time
import numpy as np


baud=115200
header=15
maxt=100


ports = list(serial.tools.list_ports.comports())
for p in ports:
    print (p)


imu = serial.Serial('COM4',baud)  ###UNCOMMENT LATER #################

print("Clearing IMU Header")
for i in range(0,header):
        data = imu.readline()
#        print(i,data)

i=0
tstart=time.time()
print("Settling IMU...")
while (i < maxt):
    i=i+1
    t=time.time() - tstart
    data = imu.readline()
    numData=data.decode()
    numData = numData.split(",")
    numData = np.array(numData[0:3], dtype=float)
    q1=numData[0]
    q2=numData[1]
    q3=numData[2]
    print(i,q1,q2,q3)
