# -*- coding: utf-8 -*-
"""
Created on Tue Aug  1 16:33:23 2023

@author: mfogel
"""

#import serial
import time
from ctypes import *



# function definition
def init_maxon():
    path='/home/pi/src/python/libEposCmd.so.6.6.2.0'
    path="C:\Users\mfogel\OneDrive - Hearst\Desktop\RasberryPi Programming\maxon\maxon motor ag\maxon motor ag\EPOS IDX\EPOS4\04 Programming\Linux Library\EPOS_Linux_Library\EPOS_Linux_Library\lib\arm\v8\libEposCmd.so.6.7.1.0"
    cdll.LoadLibrary(path)
    epos=CDLL(path)
    
    #NodeID must match with hardware DIP switches setting of EPOS4
    NodeID=1
    keyhandle=0
    # Define return variables from EPOS library functions
    ret=0
    pErrorCode=c_uint()
    pDeviceErrorCode=c_uint()
    
    #Open USB port
    print("Opening Maxon Motor USB Port...")
    keyhandle=epos.VCS_OpenDevice(b"EPOS4",b'MAXON SERIAL V2',b'USB','USB0',byref(pErrorCode))
    if (keyhandle != 0):
        print('Keyhandle: %8d' % keyhandle)
        #Verify error state
        ret=epos.VCS_GetDeviceErrorCode(keyhandle, NodeID, 1, byref(pDeviceErrorCode), byref(pErrorCode))
        print('Device Error: %#5.8x' % pDeviceErrorCode.value)
        #Device Error Evaluation
        
        
    return keyhandle, NodeID